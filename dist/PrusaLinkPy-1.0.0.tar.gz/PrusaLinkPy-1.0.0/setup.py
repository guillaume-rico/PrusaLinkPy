from setuptools import find_packages, setup

setup (
    name='prusaLinkPy',
    packages=find_packages(),
    version='1.0.0',
    description='Prusa Link Python Lib',
    author='Guillaume RICO'
)